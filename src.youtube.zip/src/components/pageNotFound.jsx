const PageNotFound = () =>{
    return(
        <div className="PNF">
            <h1>Page Not Found.....! </h1>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2MqLlWlGQR20cQJa8GBPkqalto3eMG_oMlg&usqp=CAU" width={1000} height={500} alt="" />
        </div>
    )
}
export default PageNotFound