import ban1 from '../images/ban1.png'
import '../styles/banner.css'

function Banner  () {
    return(
        <div className="banner">

            <img  src={ban1} alt="" />
        </div>
    );
}
export default Banner;




